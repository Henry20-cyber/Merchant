import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::index
* @see app/Domains/Receipt/Controllers/ReceiptController.php:19
* @route '/api/businesses/current/receipts'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/receipts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::index
* @see app/Domains/Receipt/Controllers/ReceiptController.php:19
* @route '/api/businesses/current/receipts'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::index
* @see app/Domains/Receipt/Controllers/ReceiptController.php:19
* @route '/api/businesses/current/receipts'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::index
* @see app/Domains/Receipt/Controllers/ReceiptController.php:19
* @route '/api/businesses/current/receipts'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::index
* @see app/Domains/Receipt/Controllers/ReceiptController.php:19
* @route '/api/businesses/current/receipts'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::index
* @see app/Domains/Receipt/Controllers/ReceiptController.php:19
* @route '/api/businesses/current/receipts'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::index
* @see app/Domains/Receipt/Controllers/ReceiptController.php:19
* @route '/api/businesses/current/receipts'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::show
* @see app/Domains/Receipt/Controllers/ReceiptController.php:43
* @route '/api/businesses/current/receipts/{receipt}'
*/
export const show = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/receipts/{receipt}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::show
* @see app/Domains/Receipt/Controllers/ReceiptController.php:43
* @route '/api/businesses/current/receipts/{receipt}'
*/
show.url = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { receipt: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { receipt: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            receipt: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        receipt: typeof args.receipt === 'object'
        ? args.receipt.id
        : args.receipt,
    }

    return show.definition.url
            .replace('{receipt}', parsedArgs.receipt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::show
* @see app/Domains/Receipt/Controllers/ReceiptController.php:43
* @route '/api/businesses/current/receipts/{receipt}'
*/
show.get = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::show
* @see app/Domains/Receipt/Controllers/ReceiptController.php:43
* @route '/api/businesses/current/receipts/{receipt}'
*/
show.head = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::show
* @see app/Domains/Receipt/Controllers/ReceiptController.php:43
* @route '/api/businesses/current/receipts/{receipt}'
*/
const showForm = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::show
* @see app/Domains/Receipt/Controllers/ReceiptController.php:43
* @route '/api/businesses/current/receipts/{receipt}'
*/
showForm.get = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::show
* @see app/Domains/Receipt/Controllers/ReceiptController.php:43
* @route '/api/businesses/current/receipts/{receipt}'
*/
showForm.head = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::print
* @see app/Domains/Receipt/Controllers/ReceiptController.php:71
* @route '/api/businesses/current/receipts/{receipt}/print'
*/
export const print = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/receipts/{receipt}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::print
* @see app/Domains/Receipt/Controllers/ReceiptController.php:71
* @route '/api/businesses/current/receipts/{receipt}/print'
*/
print.url = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { receipt: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { receipt: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            receipt: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        receipt: typeof args.receipt === 'object'
        ? args.receipt.id
        : args.receipt,
    }

    return print.definition.url
            .replace('{receipt}', parsedArgs.receipt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::print
* @see app/Domains/Receipt/Controllers/ReceiptController.php:71
* @route '/api/businesses/current/receipts/{receipt}/print'
*/
print.get = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::print
* @see app/Domains/Receipt/Controllers/ReceiptController.php:71
* @route '/api/businesses/current/receipts/{receipt}/print'
*/
print.head = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::print
* @see app/Domains/Receipt/Controllers/ReceiptController.php:71
* @route '/api/businesses/current/receipts/{receipt}/print'
*/
const printForm = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::print
* @see app/Domains/Receipt/Controllers/ReceiptController.php:71
* @route '/api/businesses/current/receipts/{receipt}/print'
*/
printForm.get = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::print
* @see app/Domains/Receipt/Controllers/ReceiptController.php:71
* @route '/api/businesses/current/receipts/{receipt}/print'
*/
printForm.head = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::pdf
* @see app/Domains/Receipt/Controllers/ReceiptController.php:128
* @route '/api/businesses/current/receipts/{receipt}/pdf'
*/
export const pdf = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/receipts/{receipt}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::pdf
* @see app/Domains/Receipt/Controllers/ReceiptController.php:128
* @route '/api/businesses/current/receipts/{receipt}/pdf'
*/
pdf.url = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { receipt: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { receipt: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            receipt: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        receipt: typeof args.receipt === 'object'
        ? args.receipt.id
        : args.receipt,
    }

    return pdf.definition.url
            .replace('{receipt}', parsedArgs.receipt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::pdf
* @see app/Domains/Receipt/Controllers/ReceiptController.php:128
* @route '/api/businesses/current/receipts/{receipt}/pdf'
*/
pdf.get = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::pdf
* @see app/Domains/Receipt/Controllers/ReceiptController.php:128
* @route '/api/businesses/current/receipts/{receipt}/pdf'
*/
pdf.head = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::pdf
* @see app/Domains/Receipt/Controllers/ReceiptController.php:128
* @route '/api/businesses/current/receipts/{receipt}/pdf'
*/
const pdfForm = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::pdf
* @see app/Domains/Receipt/Controllers/ReceiptController.php:128
* @route '/api/businesses/current/receipts/{receipt}/pdf'
*/
pdfForm.get = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Receipt\Controllers\ReceiptController::pdf
* @see app/Domains/Receipt/Controllers/ReceiptController.php:128
* @route '/api/businesses/current/receipts/{receipt}/pdf'
*/
pdfForm.head = (args: { receipt: string | { id: string } } | [receipt: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pdf.form = pdfForm

const ReceiptController = { index, show, print, pdf }

export default ReceiptController