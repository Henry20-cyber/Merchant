import ReceiptController from './ReceiptController'

const Controllers = {
    ReceiptController: Object.assign(ReceiptController, ReceiptController),
}

export default Controllers