import Controllers from './Controllers'

const Receipt = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Receipt