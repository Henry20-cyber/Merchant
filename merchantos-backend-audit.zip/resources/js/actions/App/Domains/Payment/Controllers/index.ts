import PaystackWebhookController from './PaystackWebhookController'

const Controllers = {
    PaystackWebhookController: Object.assign(PaystackWebhookController, PaystackWebhookController),
}

export default Controllers