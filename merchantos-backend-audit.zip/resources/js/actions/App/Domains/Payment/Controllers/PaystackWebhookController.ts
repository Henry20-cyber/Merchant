import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Domains\Payment\Controllers\PaystackWebhookController::handle
* @see app/Domains/Payment/Controllers/PaystackWebhookController.php:29
* @route '/api/webhooks/paystack'
*/
export const handle = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: handle.url(options),
    method: 'post',
})

handle.definition = {
    methods: ["post"],
    url: '/api/webhooks/paystack',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Payment\Controllers\PaystackWebhookController::handle
* @see app/Domains/Payment/Controllers/PaystackWebhookController.php:29
* @route '/api/webhooks/paystack'
*/
handle.url = (options?: RouteQueryOptions) => {
    return handle.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Payment\Controllers\PaystackWebhookController::handle
* @see app/Domains/Payment/Controllers/PaystackWebhookController.php:29
* @route '/api/webhooks/paystack'
*/
handle.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: handle.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Payment\Controllers\PaystackWebhookController::handle
* @see app/Domains/Payment/Controllers/PaystackWebhookController.php:29
* @route '/api/webhooks/paystack'
*/
const handleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: handle.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Payment\Controllers\PaystackWebhookController::handle
* @see app/Domains/Payment/Controllers/PaystackWebhookController.php:29
* @route '/api/webhooks/paystack'
*/
handleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: handle.url(options),
    method: 'post',
})

handle.form = handleForm

const PaystackWebhookController = { handle }

export default PaystackWebhookController