import Controllers from './Controllers'

const Payment = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Payment