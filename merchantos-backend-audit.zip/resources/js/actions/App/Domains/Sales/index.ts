import Http from './Http'

const Sales = {
    Http: Object.assign(Http, Http),
}

export default Sales