import SaleController from './SaleController'

const Controllers = {
    SaleController: Object.assign(SaleController, SaleController),
}

export default Controllers