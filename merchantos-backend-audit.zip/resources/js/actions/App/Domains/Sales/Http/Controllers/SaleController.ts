import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::dashboard
* @see app/Domains/Sales/Http/Controllers/SaleController.php:72
* @route '/api/businesses/current/sales/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/sales/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::dashboard
* @see app/Domains/Sales/Http/Controllers/SaleController.php:72
* @route '/api/businesses/current/sales/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::dashboard
* @see app/Domains/Sales/Http/Controllers/SaleController.php:72
* @route '/api/businesses/current/sales/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::dashboard
* @see app/Domains/Sales/Http/Controllers/SaleController.php:72
* @route '/api/businesses/current/sales/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::dashboard
* @see app/Domains/Sales/Http/Controllers/SaleController.php:72
* @route '/api/businesses/current/sales/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::dashboard
* @see app/Domains/Sales/Http/Controllers/SaleController.php:72
* @route '/api/businesses/current/sales/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::dashboard
* @see app/Domains/Sales/Http/Controllers/SaleController.php:72
* @route '/api/businesses/current/sales/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::store
* @see app/Domains/Sales/Http/Controllers/SaleController.php:18
* @route '/api/businesses/current/sales'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/businesses/current/sales',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::store
* @see app/Domains/Sales/Http/Controllers/SaleController.php:18
* @route '/api/businesses/current/sales'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::store
* @see app/Domains/Sales/Http/Controllers/SaleController.php:18
* @route '/api/businesses/current/sales'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::store
* @see app/Domains/Sales/Http/Controllers/SaleController.php:18
* @route '/api/businesses/current/sales'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Sales\Http\Controllers\SaleController::store
* @see app/Domains/Sales/Http/Controllers/SaleController.php:18
* @route '/api/businesses/current/sales'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const SaleController = { dashboard, store }

export default SaleController