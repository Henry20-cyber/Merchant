import Controllers from './Controllers'

const Inventory = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Inventory