import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Domains\Inventory\Controllers\InventoryController::index
* @see app/Domains/Inventory/Controllers/InventoryController.php:24
* @route '/api/businesses/current/inventory'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/inventory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::index
* @see app/Domains/Inventory/Controllers/InventoryController.php:24
* @route '/api/businesses/current/inventory'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::index
* @see app/Domains/Inventory/Controllers/InventoryController.php:24
* @route '/api/businesses/current/inventory'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::index
* @see app/Domains/Inventory/Controllers/InventoryController.php:24
* @route '/api/businesses/current/inventory'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::index
* @see app/Domains/Inventory/Controllers/InventoryController.php:24
* @route '/api/businesses/current/inventory'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::index
* @see app/Domains/Inventory/Controllers/InventoryController.php:24
* @route '/api/businesses/current/inventory'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::index
* @see app/Domains/Inventory/Controllers/InventoryController.php:24
* @route '/api/businesses/current/inventory'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::show
* @see app/Domains/Inventory/Controllers/InventoryController.php:46
* @route '/api/businesses/current/inventory/{stock}'
*/
export const show = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/inventory/{stock}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::show
* @see app/Domains/Inventory/Controllers/InventoryController.php:46
* @route '/api/businesses/current/inventory/{stock}'
*/
show.url = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stock: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { stock: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            stock: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stock: typeof args.stock === 'object'
        ? args.stock.id
        : args.stock,
    }

    return show.definition.url
            .replace('{stock}', parsedArgs.stock.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::show
* @see app/Domains/Inventory/Controllers/InventoryController.php:46
* @route '/api/businesses/current/inventory/{stock}'
*/
show.get = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::show
* @see app/Domains/Inventory/Controllers/InventoryController.php:46
* @route '/api/businesses/current/inventory/{stock}'
*/
show.head = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::show
* @see app/Domains/Inventory/Controllers/InventoryController.php:46
* @route '/api/businesses/current/inventory/{stock}'
*/
const showForm = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::show
* @see app/Domains/Inventory/Controllers/InventoryController.php:46
* @route '/api/businesses/current/inventory/{stock}'
*/
showForm.get = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::show
* @see app/Domains/Inventory/Controllers/InventoryController.php:46
* @route '/api/businesses/current/inventory/{stock}'
*/
showForm.head = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::receive
* @see app/Domains/Inventory/Controllers/InventoryController.php:71
* @route '/api/businesses/current/inventory/receive'
*/
export const receive = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: receive.url(options),
    method: 'post',
})

receive.definition = {
    methods: ["post"],
    url: '/api/businesses/current/inventory/receive',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::receive
* @see app/Domains/Inventory/Controllers/InventoryController.php:71
* @route '/api/businesses/current/inventory/receive'
*/
receive.url = (options?: RouteQueryOptions) => {
    return receive.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::receive
* @see app/Domains/Inventory/Controllers/InventoryController.php:71
* @route '/api/businesses/current/inventory/receive'
*/
receive.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: receive.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::receive
* @see app/Domains/Inventory/Controllers/InventoryController.php:71
* @route '/api/businesses/current/inventory/receive'
*/
const receiveForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: receive.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::receive
* @see app/Domains/Inventory/Controllers/InventoryController.php:71
* @route '/api/businesses/current/inventory/receive'
*/
receiveForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: receive.url(options),
    method: 'post',
})

receive.form = receiveForm

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::adjust
* @see app/Domains/Inventory/Controllers/InventoryController.php:138
* @route '/api/businesses/current/inventory/adjust'
*/
export const adjust = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjust.url(options),
    method: 'post',
})

adjust.definition = {
    methods: ["post"],
    url: '/api/businesses/current/inventory/adjust',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::adjust
* @see app/Domains/Inventory/Controllers/InventoryController.php:138
* @route '/api/businesses/current/inventory/adjust'
*/
adjust.url = (options?: RouteQueryOptions) => {
    return adjust.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::adjust
* @see app/Domains/Inventory/Controllers/InventoryController.php:138
* @route '/api/businesses/current/inventory/adjust'
*/
adjust.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjust.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::adjust
* @see app/Domains/Inventory/Controllers/InventoryController.php:138
* @route '/api/businesses/current/inventory/adjust'
*/
const adjustForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: adjust.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::adjust
* @see app/Domains/Inventory/Controllers/InventoryController.php:138
* @route '/api/businesses/current/inventory/adjust'
*/
adjustForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: adjust.url(options),
    method: 'post',
})

adjust.form = adjustForm

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::movements
* @see app/Domains/Inventory/Controllers/InventoryController.php:195
* @route '/api/businesses/current/inventory/{stock}/movements'
*/
export const movements = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements.url(args, options),
    method: 'get',
})

movements.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/inventory/{stock}/movements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::movements
* @see app/Domains/Inventory/Controllers/InventoryController.php:195
* @route '/api/businesses/current/inventory/{stock}/movements'
*/
movements.url = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stock: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { stock: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            stock: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stock: typeof args.stock === 'object'
        ? args.stock.id
        : args.stock,
    }

    return movements.definition.url
            .replace('{stock}', parsedArgs.stock.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::movements
* @see app/Domains/Inventory/Controllers/InventoryController.php:195
* @route '/api/businesses/current/inventory/{stock}/movements'
*/
movements.get = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::movements
* @see app/Domains/Inventory/Controllers/InventoryController.php:195
* @route '/api/businesses/current/inventory/{stock}/movements'
*/
movements.head = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: movements.url(args, options),
    method: 'head',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::movements
* @see app/Domains/Inventory/Controllers/InventoryController.php:195
* @route '/api/businesses/current/inventory/{stock}/movements'
*/
const movementsForm = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: movements.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::movements
* @see app/Domains/Inventory/Controllers/InventoryController.php:195
* @route '/api/businesses/current/inventory/{stock}/movements'
*/
movementsForm.get = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: movements.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Inventory\Controllers\InventoryController::movements
* @see app/Domains/Inventory/Controllers/InventoryController.php:195
* @route '/api/businesses/current/inventory/{stock}/movements'
*/
movementsForm.head = (args: { stock: string | { id: string } } | [stock: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: movements.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

movements.form = movementsForm

const InventoryController = { index, show, receive, adjust, movements }

export default InventoryController