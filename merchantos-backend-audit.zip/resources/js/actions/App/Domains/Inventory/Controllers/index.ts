import InventoryController from './InventoryController'

const Controllers = {
    InventoryController: Object.assign(InventoryController, InventoryController),
}

export default Controllers