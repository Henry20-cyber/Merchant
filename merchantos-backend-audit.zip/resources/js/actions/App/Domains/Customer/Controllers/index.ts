import CustomerController from './CustomerController'

const Controllers = {
    CustomerController: Object.assign(CustomerController, CustomerController),
}

export default Controllers