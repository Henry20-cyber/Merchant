import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Domains\Customer\Controllers\CustomerController::index
* @see app/Domains/Customer/Controllers/CustomerController.php:41
* @route '/api/businesses/current/customers'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/customers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Customer\Controllers\CustomerController::index
* @see app/Domains/Customer/Controllers/CustomerController.php:41
* @route '/api/businesses/current/customers'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Customer\Controllers\CustomerController::index
* @see app/Domains/Customer/Controllers/CustomerController.php:41
* @route '/api/businesses/current/customers'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::index
* @see app/Domains/Customer/Controllers/CustomerController.php:41
* @route '/api/businesses/current/customers'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::index
* @see app/Domains/Customer/Controllers/CustomerController.php:41
* @route '/api/businesses/current/customers'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::index
* @see app/Domains/Customer/Controllers/CustomerController.php:41
* @route '/api/businesses/current/customers'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::index
* @see app/Domains/Customer/Controllers/CustomerController.php:41
* @route '/api/businesses/current/customers'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Domains\Customer\Controllers\CustomerController::store
* @see app/Domains/Customer/Controllers/CustomerController.php:61
* @route '/api/businesses/current/customers'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/businesses/current/customers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Customer\Controllers\CustomerController::store
* @see app/Domains/Customer/Controllers/CustomerController.php:61
* @route '/api/businesses/current/customers'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Customer\Controllers\CustomerController::store
* @see app/Domains/Customer/Controllers/CustomerController.php:61
* @route '/api/businesses/current/customers'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::store
* @see app/Domains/Customer/Controllers/CustomerController.php:61
* @route '/api/businesses/current/customers'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::store
* @see app/Domains/Customer/Controllers/CustomerController.php:61
* @route '/api/businesses/current/customers'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Domains\Customer\Controllers\CustomerController::show
* @see app/Domains/Customer/Controllers/CustomerController.php:94
* @route '/api/businesses/current/customers/{customer}'
*/
export const show = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/customers/{customer}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Customer\Controllers\CustomerController::show
* @see app/Domains/Customer/Controllers/CustomerController.php:94
* @route '/api/businesses/current/customers/{customer}'
*/
show.url = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return show.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Customer\Controllers\CustomerController::show
* @see app/Domains/Customer/Controllers/CustomerController.php:94
* @route '/api/businesses/current/customers/{customer}'
*/
show.get = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::show
* @see app/Domains/Customer/Controllers/CustomerController.php:94
* @route '/api/businesses/current/customers/{customer}'
*/
show.head = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::show
* @see app/Domains/Customer/Controllers/CustomerController.php:94
* @route '/api/businesses/current/customers/{customer}'
*/
const showForm = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::show
* @see app/Domains/Customer/Controllers/CustomerController.php:94
* @route '/api/businesses/current/customers/{customer}'
*/
showForm.get = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::show
* @see app/Domains/Customer/Controllers/CustomerController.php:94
* @route '/api/businesses/current/customers/{customer}'
*/
showForm.head = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Domains\Customer\Controllers\CustomerController::update
* @see app/Domains/Customer/Controllers/CustomerController.php:114
* @route '/api/businesses/current/customers/{customer}'
*/
export const update = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/businesses/current/customers/{customer}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Domains\Customer\Controllers\CustomerController::update
* @see app/Domains/Customer/Controllers/CustomerController.php:114
* @route '/api/businesses/current/customers/{customer}'
*/
update.url = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return update.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Customer\Controllers\CustomerController::update
* @see app/Domains/Customer/Controllers/CustomerController.php:114
* @route '/api/businesses/current/customers/{customer}'
*/
update.put = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::update
* @see app/Domains/Customer/Controllers/CustomerController.php:114
* @route '/api/businesses/current/customers/{customer}'
*/
const updateForm = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::update
* @see app/Domains/Customer/Controllers/CustomerController.php:114
* @route '/api/businesses/current/customers/{customer}'
*/
updateForm.put = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Domains\Customer\Controllers\CustomerController::destroy
* @see app/Domains/Customer/Controllers/CustomerController.php:163
* @route '/api/businesses/current/customers/{customer}'
*/
export const destroy = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/businesses/current/customers/{customer}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Domains\Customer\Controllers\CustomerController::destroy
* @see app/Domains/Customer/Controllers/CustomerController.php:163
* @route '/api/businesses/current/customers/{customer}'
*/
destroy.url = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return destroy.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Customer\Controllers\CustomerController::destroy
* @see app/Domains/Customer/Controllers/CustomerController.php:163
* @route '/api/businesses/current/customers/{customer}'
*/
destroy.delete = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::destroy
* @see app/Domains/Customer/Controllers/CustomerController.php:163
* @route '/api/businesses/current/customers/{customer}'
*/
const destroyForm = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Customer\Controllers\CustomerController::destroy
* @see app/Domains/Customer/Controllers/CustomerController.php:163
* @route '/api/businesses/current/customers/{customer}'
*/
destroyForm.delete = (args: { customer: string | { id: string } } | [customer: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const CustomerController = { index, store, show, update, destroy }

export default CustomerController