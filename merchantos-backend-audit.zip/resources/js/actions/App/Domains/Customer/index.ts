import Controllers from './Controllers'

const Customer = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Customer