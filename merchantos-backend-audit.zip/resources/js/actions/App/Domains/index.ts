import Identity from './Identity'
import Organization from './Organization'
import Product from './Product'
import Customer from './Customer'
import Inventory from './Inventory'
import Sales from './Sales'
import Receipt from './Receipt'
import Subscription from './Subscription'
import Payment from './Payment'

const Domains = {
    Identity: Object.assign(Identity, Identity),
    Organization: Object.assign(Organization, Organization),
    Product: Object.assign(Product, Product),
    Customer: Object.assign(Customer, Customer),
    Inventory: Object.assign(Inventory, Inventory),
    Sales: Object.assign(Sales, Sales),
    Receipt: Object.assign(Receipt, Receipt),
    Subscription: Object.assign(Subscription, Subscription),
    Payment: Object.assign(Payment, Payment),
}

export default Domains