import Controllers from './Controllers'

const Organization = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Organization