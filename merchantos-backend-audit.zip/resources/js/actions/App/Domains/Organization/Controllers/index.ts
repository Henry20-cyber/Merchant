import BusinessController from './BusinessController'
import BusinessContextController from './BusinessContextController'
import BusinessMemberController from './BusinessMemberController'

const Controllers = {
    BusinessController: Object.assign(BusinessController, BusinessController),
    BusinessContextController: Object.assign(BusinessContextController, BusinessContextController),
    BusinessMemberController: Object.assign(BusinessMemberController, BusinessMemberController),
}

export default Controllers