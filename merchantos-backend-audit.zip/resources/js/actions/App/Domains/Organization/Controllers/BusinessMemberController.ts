import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::index
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:19
* @route '/api/businesses/current/members'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/members',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::index
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:19
* @route '/api/businesses/current/members'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::index
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:19
* @route '/api/businesses/current/members'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::index
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:19
* @route '/api/businesses/current/members'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::index
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:19
* @route '/api/businesses/current/members'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::index
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:19
* @route '/api/businesses/current/members'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::index
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:19
* @route '/api/businesses/current/members'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::assignRole
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:45
* @route '/api/businesses/current/members/{user}/role'
*/
export const assignRole = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: assignRole.url(args, options),
    method: 'put',
})

assignRole.definition = {
    methods: ["put"],
    url: '/api/businesses/current/members/{user}/role',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::assignRole
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:45
* @route '/api/businesses/current/members/{user}/role'
*/
assignRole.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return assignRole.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::assignRole
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:45
* @route '/api/businesses/current/members/{user}/role'
*/
assignRole.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: assignRole.url(args, options),
    method: 'put',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::assignRole
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:45
* @route '/api/businesses/current/members/{user}/role'
*/
const assignRoleForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: assignRole.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessMemberController::assignRole
* @see app/Domains/Organization/Controllers/BusinessMemberController.php:45
* @route '/api/businesses/current/members/{user}/role'
*/
assignRoleForm.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: assignRole.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

assignRole.form = assignRoleForm

const BusinessMemberController = { index, assignRole }

export default BusinessMemberController