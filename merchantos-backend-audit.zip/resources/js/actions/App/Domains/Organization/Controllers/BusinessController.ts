import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Domains\Organization\Controllers\BusinessController::store
* @see app/Domains/Organization/Controllers/BusinessController.php:24
* @route '/api/businesses'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/businesses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessController::store
* @see app/Domains/Organization/Controllers/BusinessController.php:24
* @route '/api/businesses'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessController::store
* @see app/Domains/Organization/Controllers/BusinessController.php:24
* @route '/api/businesses'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::store
* @see app/Domains/Organization/Controllers/BusinessController.php:24
* @route '/api/businesses'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::store
* @see app/Domains/Organization/Controllers/BusinessController.php:24
* @route '/api/businesses'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Domains\Organization\Controllers\BusinessController::show
* @see app/Domains/Organization/Controllers/BusinessController.php:69
* @route '/api/businesses/{business}'
*/
export const show = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/businesses/{business}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessController::show
* @see app/Domains/Organization/Controllers/BusinessController.php:69
* @route '/api/businesses/{business}'
*/
show.url = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { business: args }
    }

    if (Array.isArray(args)) {
        args = {
            business: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        business: args.business,
    }

    return show.definition.url
            .replace('{business}', parsedArgs.business.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessController::show
* @see app/Domains/Organization/Controllers/BusinessController.php:69
* @route '/api/businesses/{business}'
*/
show.get = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::show
* @see app/Domains/Organization/Controllers/BusinessController.php:69
* @route '/api/businesses/{business}'
*/
show.head = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::show
* @see app/Domains/Organization/Controllers/BusinessController.php:69
* @route '/api/businesses/{business}'
*/
const showForm = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::show
* @see app/Domains/Organization/Controllers/BusinessController.php:69
* @route '/api/businesses/{business}'
*/
showForm.get = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::show
* @see app/Domains/Organization/Controllers/BusinessController.php:69
* @route '/api/businesses/{business}'
*/
showForm.head = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Domains\Organization\Controllers\BusinessController::update
* @see app/Domains/Organization/Controllers/BusinessController.php:90
* @route '/api/businesses/{business}'
*/
export const update = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/businesses/{business}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessController::update
* @see app/Domains/Organization/Controllers/BusinessController.php:90
* @route '/api/businesses/{business}'
*/
update.url = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { business: args }
    }

    if (Array.isArray(args)) {
        args = {
            business: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        business: args.business,
    }

    return update.definition.url
            .replace('{business}', parsedArgs.business.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessController::update
* @see app/Domains/Organization/Controllers/BusinessController.php:90
* @route '/api/businesses/{business}'
*/
update.put = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::update
* @see app/Domains/Organization/Controllers/BusinessController.php:90
* @route '/api/businesses/{business}'
*/
const updateForm = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::update
* @see app/Domains/Organization/Controllers/BusinessController.php:90
* @route '/api/businesses/{business}'
*/
updateForm.put = (args: { business: string | number } | [business: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Domains\Organization\Controllers\BusinessController::current
* @see app/Domains/Organization/Controllers/BusinessController.php:40
* @route '/api/businesses/current'
*/
export const current = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: current.url(options),
    method: 'get',
})

current.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessController::current
* @see app/Domains/Organization/Controllers/BusinessController.php:40
* @route '/api/businesses/current'
*/
current.url = (options?: RouteQueryOptions) => {
    return current.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessController::current
* @see app/Domains/Organization/Controllers/BusinessController.php:40
* @route '/api/businesses/current'
*/
current.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: current.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::current
* @see app/Domains/Organization/Controllers/BusinessController.php:40
* @route '/api/businesses/current'
*/
current.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: current.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::current
* @see app/Domains/Organization/Controllers/BusinessController.php:40
* @route '/api/businesses/current'
*/
const currentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::current
* @see app/Domains/Organization/Controllers/BusinessController.php:40
* @route '/api/businesses/current'
*/
currentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessController::current
* @see app/Domains/Organization/Controllers/BusinessController.php:40
* @route '/api/businesses/current'
*/
currentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

current.form = currentForm

const BusinessController = { store, show, update, current }

export default BusinessController