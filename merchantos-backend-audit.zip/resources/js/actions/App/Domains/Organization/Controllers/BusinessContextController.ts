import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/api/businesses/{business}/switch'
*/
const set53435769836909542126dd6bde673707 = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: set53435769836909542126dd6bde673707.url(args, options),
    method: 'post',
})

set53435769836909542126dd6bde673707.definition = {
    methods: ["post"],
    url: '/api/businesses/{business}/switch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/api/businesses/{business}/switch'
*/
set53435769836909542126dd6bde673707.url = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { business: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { business: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            business: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        business: typeof args.business === 'object'
        ? args.business.id
        : args.business,
    }

    return set53435769836909542126dd6bde673707.definition.url
            .replace('{business}', parsedArgs.business.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/api/businesses/{business}/switch'
*/
set53435769836909542126dd6bde673707.post = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: set53435769836909542126dd6bde673707.url(args, options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/api/businesses/{business}/switch'
*/
const set53435769836909542126dd6bde673707Form = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: set53435769836909542126dd6bde673707.url(args, options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/api/businesses/{business}/switch'
*/
set53435769836909542126dd6bde673707Form.post = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: set53435769836909542126dd6bde673707.url(args, options),
    method: 'post',
})

set53435769836909542126dd6bde673707.form = set53435769836909542126dd6bde673707Form
/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/businesses/{business}/switch'
*/
const set001921676feed52bd2d0a3e1f5f8bbe4 = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: set001921676feed52bd2d0a3e1f5f8bbe4.url(args, options),
    method: 'post',
})

set001921676feed52bd2d0a3e1f5f8bbe4.definition = {
    methods: ["post"],
    url: '/businesses/{business}/switch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/businesses/{business}/switch'
*/
set001921676feed52bd2d0a3e1f5f8bbe4.url = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { business: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { business: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            business: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        business: typeof args.business === 'object'
        ? args.business.id
        : args.business,
    }

    return set001921676feed52bd2d0a3e1f5f8bbe4.definition.url
            .replace('{business}', parsedArgs.business.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/businesses/{business}/switch'
*/
set001921676feed52bd2d0a3e1f5f8bbe4.post = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: set001921676feed52bd2d0a3e1f5f8bbe4.url(args, options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/businesses/{business}/switch'
*/
const set001921676feed52bd2d0a3e1f5f8bbe4Form = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: set001921676feed52bd2d0a3e1f5f8bbe4.url(args, options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::set
* @see app/Domains/Organization/Controllers/BusinessContextController.php:12
* @route '/businesses/{business}/switch'
*/
set001921676feed52bd2d0a3e1f5f8bbe4Form.post = (args: { business: string | { id: string } } | [business: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: set001921676feed52bd2d0a3e1f5f8bbe4.url(args, options),
    method: 'post',
})

set001921676feed52bd2d0a3e1f5f8bbe4.form = set001921676feed52bd2d0a3e1f5f8bbe4Form

/**
* Multiple routes resolve to \App\Domains\Organization\Controllers\BusinessContextController::set, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `set['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const set = {
    '/api/businesses/{business}/switch': set53435769836909542126dd6bde673707,
    '/businesses/{business}/switch': set001921676feed52bd2d0a3e1f5f8bbe4,
}

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/api/business/current'
*/
const current67d7a30216fa70d09cfe6ae940de0b02 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: current67d7a30216fa70d09cfe6ae940de0b02.url(options),
    method: 'get',
})

current67d7a30216fa70d09cfe6ae940de0b02.definition = {
    methods: ["get","head"],
    url: '/api/business/current',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/api/business/current'
*/
current67d7a30216fa70d09cfe6ae940de0b02.url = (options?: RouteQueryOptions) => {
    return current67d7a30216fa70d09cfe6ae940de0b02.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/api/business/current'
*/
current67d7a30216fa70d09cfe6ae940de0b02.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: current67d7a30216fa70d09cfe6ae940de0b02.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/api/business/current'
*/
current67d7a30216fa70d09cfe6ae940de0b02.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: current67d7a30216fa70d09cfe6ae940de0b02.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/api/business/current'
*/
const current67d7a30216fa70d09cfe6ae940de0b02Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current67d7a30216fa70d09cfe6ae940de0b02.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/api/business/current'
*/
current67d7a30216fa70d09cfe6ae940de0b02Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current67d7a30216fa70d09cfe6ae940de0b02.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/api/business/current'
*/
current67d7a30216fa70d09cfe6ae940de0b02Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current67d7a30216fa70d09cfe6ae940de0b02.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

current67d7a30216fa70d09cfe6ae940de0b02.form = current67d7a30216fa70d09cfe6ae940de0b02Form
/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/business/current'
*/
const currentd8dc2369f28cd64075f15e509b9c54d8 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: currentd8dc2369f28cd64075f15e509b9c54d8.url(options),
    method: 'get',
})

currentd8dc2369f28cd64075f15e509b9c54d8.definition = {
    methods: ["get","head"],
    url: '/business/current',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/business/current'
*/
currentd8dc2369f28cd64075f15e509b9c54d8.url = (options?: RouteQueryOptions) => {
    return currentd8dc2369f28cd64075f15e509b9c54d8.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/business/current'
*/
currentd8dc2369f28cd64075f15e509b9c54d8.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: currentd8dc2369f28cd64075f15e509b9c54d8.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/business/current'
*/
currentd8dc2369f28cd64075f15e509b9c54d8.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: currentd8dc2369f28cd64075f15e509b9c54d8.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/business/current'
*/
const currentd8dc2369f28cd64075f15e509b9c54d8Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: currentd8dc2369f28cd64075f15e509b9c54d8.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/business/current'
*/
currentd8dc2369f28cd64075f15e509b9c54d8Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: currentd8dc2369f28cd64075f15e509b9c54d8.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::current
* @see app/Domains/Organization/Controllers/BusinessContextController.php:31
* @route '/business/current'
*/
currentd8dc2369f28cd64075f15e509b9c54d8Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: currentd8dc2369f28cd64075f15e509b9c54d8.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

currentd8dc2369f28cd64075f15e509b9c54d8.form = currentd8dc2369f28cd64075f15e509b9c54d8Form

/**
* Multiple routes resolve to \App\Domains\Organization\Controllers\BusinessContextController::current, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `current['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const current = {
    '/api/business/current': current67d7a30216fa70d09cfe6ae940de0b02,
    '/business/current': currentd8dc2369f28cd64075f15e509b9c54d8,
}

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/api/business/current/clear'
*/
const clear8ee0ef22d74dd92ee820aa21422a5dc5 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear8ee0ef22d74dd92ee820aa21422a5dc5.url(options),
    method: 'post',
})

clear8ee0ef22d74dd92ee820aa21422a5dc5.definition = {
    methods: ["post"],
    url: '/api/business/current/clear',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/api/business/current/clear'
*/
clear8ee0ef22d74dd92ee820aa21422a5dc5.url = (options?: RouteQueryOptions) => {
    return clear8ee0ef22d74dd92ee820aa21422a5dc5.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/api/business/current/clear'
*/
clear8ee0ef22d74dd92ee820aa21422a5dc5.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear8ee0ef22d74dd92ee820aa21422a5dc5.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/api/business/current/clear'
*/
const clear8ee0ef22d74dd92ee820aa21422a5dc5Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clear8ee0ef22d74dd92ee820aa21422a5dc5.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/api/business/current/clear'
*/
clear8ee0ef22d74dd92ee820aa21422a5dc5Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clear8ee0ef22d74dd92ee820aa21422a5dc5.url(options),
    method: 'post',
})

clear8ee0ef22d74dd92ee820aa21422a5dc5.form = clear8ee0ef22d74dd92ee820aa21422a5dc5Form
/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/business/current/clear'
*/
const clear1203c44c703bea86448bc60faf82339e = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear1203c44c703bea86448bc60faf82339e.url(options),
    method: 'post',
})

clear1203c44c703bea86448bc60faf82339e.definition = {
    methods: ["post"],
    url: '/business/current/clear',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/business/current/clear'
*/
clear1203c44c703bea86448bc60faf82339e.url = (options?: RouteQueryOptions) => {
    return clear1203c44c703bea86448bc60faf82339e.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/business/current/clear'
*/
clear1203c44c703bea86448bc60faf82339e.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear1203c44c703bea86448bc60faf82339e.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/business/current/clear'
*/
const clear1203c44c703bea86448bc60faf82339eForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clear1203c44c703bea86448bc60faf82339e.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Organization\Controllers\BusinessContextController::clear
* @see app/Domains/Organization/Controllers/BusinessContextController.php:55
* @route '/business/current/clear'
*/
clear1203c44c703bea86448bc60faf82339eForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clear1203c44c703bea86448bc60faf82339e.url(options),
    method: 'post',
})

clear1203c44c703bea86448bc60faf82339e.form = clear1203c44c703bea86448bc60faf82339eForm

/**
* Multiple routes resolve to \App\Domains\Organization\Controllers\BusinessContextController::clear, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `clear['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const clear = {
    '/api/business/current/clear': clear8ee0ef22d74dd92ee820aa21422a5dc5,
    '/business/current/clear': clear1203c44c703bea86448bc60faf82339e,
}

const BusinessContextController = { set, current, clear }

export default BusinessContextController