import Controllers from './Controllers'

const Product = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Product