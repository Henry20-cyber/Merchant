import ProductController from './ProductController'

const Controllers = {
    ProductController: Object.assign(ProductController, ProductController),
}

export default Controllers