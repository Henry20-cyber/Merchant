import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Domains\Product\Controllers\ProductController::index
* @see app/Domains/Product/Controllers/ProductController.php:50
* @route '/api/businesses/current/products'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::index
* @see app/Domains/Product/Controllers/ProductController.php:50
* @route '/api/businesses/current/products'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::index
* @see app/Domains/Product/Controllers/ProductController.php:50
* @route '/api/businesses/current/products'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::index
* @see app/Domains/Product/Controllers/ProductController.php:50
* @route '/api/businesses/current/products'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::index
* @see app/Domains/Product/Controllers/ProductController.php:50
* @route '/api/businesses/current/products'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::index
* @see app/Domains/Product/Controllers/ProductController.php:50
* @route '/api/businesses/current/products'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::index
* @see app/Domains/Product/Controllers/ProductController.php:50
* @route '/api/businesses/current/products'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Domains\Product\Controllers\ProductController::store
* @see app/Domains/Product/Controllers/ProductController.php:69
* @route '/api/businesses/current/products'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/businesses/current/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::store
* @see app/Domains/Product/Controllers/ProductController.php:69
* @route '/api/businesses/current/products'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::store
* @see app/Domains/Product/Controllers/ProductController.php:69
* @route '/api/businesses/current/products'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::store
* @see app/Domains/Product/Controllers/ProductController.php:69
* @route '/api/businesses/current/products'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::store
* @see app/Domains/Product/Controllers/ProductController.php:69
* @route '/api/businesses/current/products'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Domains\Product\Controllers\ProductController::show
* @see app/Domains/Product/Controllers/ProductController.php:175
* @route '/api/businesses/current/products/{product}'
*/
export const show = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/products/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::show
* @see app/Domains/Product/Controllers/ProductController.php:175
* @route '/api/businesses/current/products/{product}'
*/
show.url = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return show.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::show
* @see app/Domains/Product/Controllers/ProductController.php:175
* @route '/api/businesses/current/products/{product}'
*/
show.get = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::show
* @see app/Domains/Product/Controllers/ProductController.php:175
* @route '/api/businesses/current/products/{product}'
*/
show.head = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::show
* @see app/Domains/Product/Controllers/ProductController.php:175
* @route '/api/businesses/current/products/{product}'
*/
const showForm = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::show
* @see app/Domains/Product/Controllers/ProductController.php:175
* @route '/api/businesses/current/products/{product}'
*/
showForm.get = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::show
* @see app/Domains/Product/Controllers/ProductController.php:175
* @route '/api/businesses/current/products/{product}'
*/
showForm.head = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Domains\Product\Controllers\ProductController::update
* @see app/Domains/Product/Controllers/ProductController.php:197
* @route '/api/businesses/current/products/{product}'
*/
export const update = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/businesses/current/products/{product}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::update
* @see app/Domains/Product/Controllers/ProductController.php:197
* @route '/api/businesses/current/products/{product}'
*/
update.url = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return update.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::update
* @see app/Domains/Product/Controllers/ProductController.php:197
* @route '/api/businesses/current/products/{product}'
*/
update.put = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::update
* @see app/Domains/Product/Controllers/ProductController.php:197
* @route '/api/businesses/current/products/{product}'
*/
const updateForm = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::update
* @see app/Domains/Product/Controllers/ProductController.php:197
* @route '/api/businesses/current/products/{product}'
*/
updateForm.put = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Domains\Product\Controllers\ProductController::destroy
* @see app/Domains/Product/Controllers/ProductController.php:248
* @route '/api/businesses/current/products/{product}'
*/
export const destroy = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/businesses/current/products/{product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::destroy
* @see app/Domains/Product/Controllers/ProductController.php:248
* @route '/api/businesses/current/products/{product}'
*/
destroy.url = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return destroy.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::destroy
* @see app/Domains/Product/Controllers/ProductController.php:248
* @route '/api/businesses/current/products/{product}'
*/
destroy.delete = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::destroy
* @see app/Domains/Product/Controllers/ProductController.php:248
* @route '/api/businesses/current/products/{product}'
*/
const destroyForm = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::destroy
* @see app/Domains/Product/Controllers/ProductController.php:248
* @route '/api/businesses/current/products/{product}'
*/
destroyForm.delete = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Domains\Product\Controllers\ProductController::storeUnit
* @see app/Domains/Product/Controllers/ProductController.php:280
* @route '/api/businesses/current/products/{product}/units'
*/
export const storeUnit = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeUnit.url(args, options),
    method: 'post',
})

storeUnit.definition = {
    methods: ["post"],
    url: '/api/businesses/current/products/{product}/units',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::storeUnit
* @see app/Domains/Product/Controllers/ProductController.php:280
* @route '/api/businesses/current/products/{product}/units'
*/
storeUnit.url = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return storeUnit.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::storeUnit
* @see app/Domains/Product/Controllers/ProductController.php:280
* @route '/api/businesses/current/products/{product}/units'
*/
storeUnit.post = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeUnit.url(args, options),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::storeUnit
* @see app/Domains/Product/Controllers/ProductController.php:280
* @route '/api/businesses/current/products/{product}/units'
*/
const storeUnitForm = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeUnit.url(args, options),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::storeUnit
* @see app/Domains/Product/Controllers/ProductController.php:280
* @route '/api/businesses/current/products/{product}/units'
*/
storeUnitForm.post = (args: { product: string | { id: string } } | [product: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeUnit.url(args, options),
    method: 'post',
})

storeUnit.form = storeUnitForm

/**
* @see \App\Domains\Product\Controllers\ProductController::updateUnit
* @see app/Domains/Product/Controllers/ProductController.php:349
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
export const updateUnit = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateUnit.url(args, options),
    method: 'put',
})

updateUnit.definition = {
    methods: ["put"],
    url: '/api/businesses/current/products/{product}/units/{unit}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::updateUnit
* @see app/Domains/Product/Controllers/ProductController.php:349
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
updateUnit.url = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            product: args[0],
            unit: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
        unit: typeof args.unit === 'object'
        ? args.unit.id
        : args.unit,
    }

    return updateUnit.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::updateUnit
* @see app/Domains/Product/Controllers/ProductController.php:349
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
updateUnit.put = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateUnit.url(args, options),
    method: 'put',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::updateUnit
* @see app/Domains/Product/Controllers/ProductController.php:349
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
const updateUnitForm = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateUnit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::updateUnit
* @see app/Domains/Product/Controllers/ProductController.php:349
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
updateUnitForm.put = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateUnit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateUnit.form = updateUnitForm

/**
* @see \App\Domains\Product\Controllers\ProductController::setBaseUnit
* @see app/Domains/Product/Controllers/ProductController.php:431
* @route '/api/businesses/current/products/{product}/units/{unit}/base'
*/
export const setBaseUnit = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setBaseUnit.url(args, options),
    method: 'post',
})

setBaseUnit.definition = {
    methods: ["post"],
    url: '/api/businesses/current/products/{product}/units/{unit}/base',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::setBaseUnit
* @see app/Domains/Product/Controllers/ProductController.php:431
* @route '/api/businesses/current/products/{product}/units/{unit}/base'
*/
setBaseUnit.url = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            product: args[0],
            unit: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
        unit: typeof args.unit === 'object'
        ? args.unit.id
        : args.unit,
    }

    return setBaseUnit.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::setBaseUnit
* @see app/Domains/Product/Controllers/ProductController.php:431
* @route '/api/businesses/current/products/{product}/units/{unit}/base'
*/
setBaseUnit.post = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setBaseUnit.url(args, options),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::setBaseUnit
* @see app/Domains/Product/Controllers/ProductController.php:431
* @route '/api/businesses/current/products/{product}/units/{unit}/base'
*/
const setBaseUnitForm = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: setBaseUnit.url(args, options),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::setBaseUnit
* @see app/Domains/Product/Controllers/ProductController.php:431
* @route '/api/businesses/current/products/{product}/units/{unit}/base'
*/
setBaseUnitForm.post = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: setBaseUnit.url(args, options),
    method: 'post',
})

setBaseUnit.form = setBaseUnitForm

/**
* @see \App\Domains\Product\Controllers\ProductController::destroyUnit
* @see app/Domains/Product/Controllers/ProductController.php:465
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
export const destroyUnit = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyUnit.url(args, options),
    method: 'delete',
})

destroyUnit.definition = {
    methods: ["delete"],
    url: '/api/businesses/current/products/{product}/units/{unit}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Domains\Product\Controllers\ProductController::destroyUnit
* @see app/Domains/Product/Controllers/ProductController.php:465
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
destroyUnit.url = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            product: args[0],
            unit: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
        unit: typeof args.unit === 'object'
        ? args.unit.id
        : args.unit,
    }

    return destroyUnit.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Product\Controllers\ProductController::destroyUnit
* @see app/Domains/Product/Controllers/ProductController.php:465
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
destroyUnit.delete = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyUnit.url(args, options),
    method: 'delete',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::destroyUnit
* @see app/Domains/Product/Controllers/ProductController.php:465
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
const destroyUnitForm = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyUnit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Product\Controllers\ProductController::destroyUnit
* @see app/Domains/Product/Controllers/ProductController.php:465
* @route '/api/businesses/current/products/{product}/units/{unit}'
*/
destroyUnitForm.delete = (args: { product: string | { id: string }, unit: string | { id: string } } | [product: string | { id: string }, unit: string | { id: string } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyUnit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyUnit.form = destroyUnitForm

const ProductController = { index, store, show, update, destroy, storeUnit, updateUnit, setBaseUnit, destroyUnit }

export default ProductController