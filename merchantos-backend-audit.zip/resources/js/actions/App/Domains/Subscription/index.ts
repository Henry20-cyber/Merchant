import Controllers from './Controllers'

const Subscription = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Subscription