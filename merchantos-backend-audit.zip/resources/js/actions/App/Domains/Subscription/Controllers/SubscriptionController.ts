import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::plans
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:102
* @route '/api/subscription-plans'
*/
export const plans = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: plans.url(options),
    method: 'get',
})

plans.definition = {
    methods: ["get","head"],
    url: '/api/subscription-plans',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::plans
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:102
* @route '/api/subscription-plans'
*/
plans.url = (options?: RouteQueryOptions) => {
    return plans.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::plans
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:102
* @route '/api/subscription-plans'
*/
plans.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: plans.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::plans
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:102
* @route '/api/subscription-plans'
*/
plans.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: plans.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::plans
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:102
* @route '/api/subscription-plans'
*/
const plansForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: plans.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::plans
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:102
* @route '/api/subscription-plans'
*/
plansForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: plans.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::plans
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:102
* @route '/api/subscription-plans'
*/
plansForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: plans.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

plans.form = plansForm

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::current
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:25
* @route '/api/businesses/current/subscription'
*/
export const current = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: current.url(options),
    method: 'get',
})

current.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/subscription',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::current
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:25
* @route '/api/businesses/current/subscription'
*/
current.url = (options?: RouteQueryOptions) => {
    return current.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::current
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:25
* @route '/api/businesses/current/subscription'
*/
current.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: current.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::current
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:25
* @route '/api/businesses/current/subscription'
*/
current.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: current.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::current
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:25
* @route '/api/businesses/current/subscription'
*/
const currentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::current
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:25
* @route '/api/businesses/current/subscription'
*/
currentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::current
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:25
* @route '/api/businesses/current/subscription'
*/
currentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: current.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

current.form = currentForm

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::checkout
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:130
* @route '/api/businesses/current/subscription/checkout'
*/
export const checkout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

checkout.definition = {
    methods: ["post"],
    url: '/api/businesses/current/subscription/checkout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::checkout
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:130
* @route '/api/businesses/current/subscription/checkout'
*/
checkout.url = (options?: RouteQueryOptions) => {
    return checkout.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::checkout
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:130
* @route '/api/businesses/current/subscription/checkout'
*/
checkout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::checkout
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:130
* @route '/api/businesses/current/subscription/checkout'
*/
const checkoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: checkout.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Subscription\Controllers\SubscriptionController::checkout
* @see app/Domains/Subscription/Controllers/SubscriptionController.php:130
* @route '/api/businesses/current/subscription/checkout'
*/
checkoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: checkout.url(options),
    method: 'post',
})

checkout.form = checkoutForm

const SubscriptionController = { plans, current, checkout }

export default SubscriptionController