import SubscriptionController from './SubscriptionController'

const Controllers = {
    SubscriptionController: Object.assign(SubscriptionController, SubscriptionController),
}

export default Controllers