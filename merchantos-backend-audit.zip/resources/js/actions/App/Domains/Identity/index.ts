import Controllers from './Controllers'

const Identity = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Identity