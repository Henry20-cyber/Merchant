import AuthController from './AuthController'
import RoleController from './RoleController'

const Controllers = {
    AuthController: Object.assign(AuthController, AuthController),
    RoleController: Object.assign(RoleController, RoleController),
}

export default Controllers