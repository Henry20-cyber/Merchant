import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Domains\Identity\Controllers\AuthController::register
* @see app/Domains/Identity/Controllers/AuthController.php:26
* @route '/api/auth/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/api/auth/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Identity\Controllers\AuthController::register
* @see app/Domains/Identity/Controllers/AuthController.php:26
* @route '/api/auth/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Identity\Controllers\AuthController::register
* @see app/Domains/Identity/Controllers/AuthController.php:26
* @route '/api/auth/register'
*/
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Identity\Controllers\AuthController::register
* @see app/Domains/Identity/Controllers/AuthController.php:26
* @route '/api/auth/register'
*/
const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: register.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Identity\Controllers\AuthController::register
* @see app/Domains/Identity/Controllers/AuthController.php:26
* @route '/api/auth/register'
*/
registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: register.url(options),
    method: 'post',
})

register.form = registerForm

/**
* @see \App\Domains\Identity\Controllers\AuthController::login
* @see app/Domains/Identity/Controllers/AuthController.php:57
* @route '/api/auth/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/api/auth/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Identity\Controllers\AuthController::login
* @see app/Domains/Identity/Controllers/AuthController.php:57
* @route '/api/auth/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Identity\Controllers\AuthController::login
* @see app/Domains/Identity/Controllers/AuthController.php:57
* @route '/api/auth/login'
*/
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Identity\Controllers\AuthController::login
* @see app/Domains/Identity/Controllers/AuthController.php:57
* @route '/api/auth/login'
*/
const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: login.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Identity\Controllers\AuthController::login
* @see app/Domains/Identity/Controllers/AuthController.php:57
* @route '/api/auth/login'
*/
loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: login.url(options),
    method: 'post',
})

login.form = loginForm

const AuthController = { register, login }

export default AuthController