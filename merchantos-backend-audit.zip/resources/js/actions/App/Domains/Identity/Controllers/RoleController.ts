import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Domains\Identity\Controllers\RoleController::index
* @see app/Domains/Identity/Controllers/RoleController.php:58
* @route '/api/businesses/current/roles'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/businesses/current/roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Domains\Identity\Controllers\RoleController::index
* @see app/Domains/Identity/Controllers/RoleController.php:58
* @route '/api/businesses/current/roles'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Identity\Controllers\RoleController::index
* @see app/Domains/Identity/Controllers/RoleController.php:58
* @route '/api/businesses/current/roles'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::index
* @see app/Domains/Identity/Controllers/RoleController.php:58
* @route '/api/businesses/current/roles'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::index
* @see app/Domains/Identity/Controllers/RoleController.php:58
* @route '/api/businesses/current/roles'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::index
* @see app/Domains/Identity/Controllers/RoleController.php:58
* @route '/api/businesses/current/roles'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::index
* @see app/Domains/Identity/Controllers/RoleController.php:58
* @route '/api/businesses/current/roles'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Domains\Identity\Controllers\RoleController::store
* @see app/Domains/Identity/Controllers/RoleController.php:18
* @route '/api/businesses/current/roles'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/businesses/current/roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Domains\Identity\Controllers\RoleController::store
* @see app/Domains/Identity/Controllers/RoleController.php:18
* @route '/api/businesses/current/roles'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Domains\Identity\Controllers\RoleController::store
* @see app/Domains/Identity/Controllers/RoleController.php:18
* @route '/api/businesses/current/roles'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::store
* @see app/Domains/Identity/Controllers/RoleController.php:18
* @route '/api/businesses/current/roles'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::store
* @see app/Domains/Identity/Controllers/RoleController.php:18
* @route '/api/businesses/current/roles'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Domains\Identity\Controllers\RoleController::update
* @see app/Domains/Identity/Controllers/RoleController.php:86
* @route '/api/businesses/current/roles/{role}'
*/
export const update = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/businesses/current/roles/{role}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Domains\Identity\Controllers\RoleController::update
* @see app/Domains/Identity/Controllers/RoleController.php:86
* @route '/api/businesses/current/roles/{role}'
*/
update.url = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

    if (Array.isArray(args)) {
        args = {
            role: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        role: args.role,
    }

    return update.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Identity\Controllers\RoleController::update
* @see app/Domains/Identity/Controllers/RoleController.php:86
* @route '/api/businesses/current/roles/{role}'
*/
update.put = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::update
* @see app/Domains/Identity/Controllers/RoleController.php:86
* @route '/api/businesses/current/roles/{role}'
*/
const updateForm = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::update
* @see app/Domains/Identity/Controllers/RoleController.php:86
* @route '/api/businesses/current/roles/{role}'
*/
updateForm.put = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Domains\Identity\Controllers\RoleController::destroy
* @see app/Domains/Identity/Controllers/RoleController.php:120
* @route '/api/businesses/current/roles/{role}'
*/
export const destroy = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/businesses/current/roles/{role}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Domains\Identity\Controllers\RoleController::destroy
* @see app/Domains/Identity/Controllers/RoleController.php:120
* @route '/api/businesses/current/roles/{role}'
*/
destroy.url = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

    if (Array.isArray(args)) {
        args = {
            role: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        role: args.role,
    }

    return destroy.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Domains\Identity\Controllers\RoleController::destroy
* @see app/Domains/Identity/Controllers/RoleController.php:120
* @route '/api/businesses/current/roles/{role}'
*/
destroy.delete = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::destroy
* @see app/Domains/Identity/Controllers/RoleController.php:120
* @route '/api/businesses/current/roles/{role}'
*/
const destroyForm = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Domains\Identity\Controllers\RoleController::destroy
* @see app/Domains/Identity/Controllers/RoleController.php:120
* @route '/api/businesses/current/roles/{role}'
*/
destroyForm.delete = (args: { role: string | number } | [role: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const RoleController = { index, store, update, destroy }

export default RoleController