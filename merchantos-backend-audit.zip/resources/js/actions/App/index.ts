import Domains from './Domains'

const App = {
    Domains: Object.assign(Domains, Domains),
}

export default App