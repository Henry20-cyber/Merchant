<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $teams = config('permission.teams');

        $tableNames = config('permission.table_names');

        $columnNames = config('permission.column_names');

        $pivotRole = $columnNames['role_pivot_key'] ?? 'role_id';

        $pivotPermission = $columnNames['permission_pivot_key'] ?? 'permission_id';

        if (! $teams) {
            return;
        }

        throw_if(
            empty($tableNames),
            'Error: config/permission.php not loaded. Run [php artisan config:clear] and try again.'
        );

        throw_if(
            empty($columnNames['team_foreign_key'] ?? null),
            'Error: team_foreign_key on config/permission.php not loaded. Run [php artisan config:clear] and try again.'
        );

        /*
        |--------------------------------------------------------------------------
        | Roles
        |--------------------------------------------------------------------------
        */

        if (! Schema::hasColumn(
            $tableNames['roles'],
            $columnNames['team_foreign_key']
        )) {
            Schema::table(
                $tableNames['roles'],
                function (Blueprint $table) use ($columnNames) {

                    $table->uuid(
                        $columnNames['team_foreign_key']
                    )->nullable()->after('id');

                    $table->index(
                        $columnNames['team_foreign_key'],
                        'roles_team_foreign_key_index'
                    );

                    $table->dropUnique(
                        'roles_name_guard_name_unique'
                    );

                    $table->unique([
                        $columnNames['team_foreign_key'],
                        'name',
                        'guard_name',
                    ]);
                }
            );

            /*
             * Roles belong to MerchantOS businesses.
             */
            Schema::table(
                $tableNames['roles'],
                function (Blueprint $table) use ($columnNames) {

                    $table->foreign(
                        $columnNames['team_foreign_key']
                    )
                        ->references('id')
                        ->on('businesses')
                        ->nullOnDelete();
                }
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Model Has Permissions
        |--------------------------------------------------------------------------
        */

        if (! Schema::hasColumn(
            $tableNames['model_has_permissions'],
            $columnNames['team_foreign_key']
        )) {
            Schema::table(
                $tableNames['model_has_permissions'],
                function (Blueprint $table) use (
                    $tableNames,
                    $columnNames,
                    $pivotPermission
                ) {

                    $table->uuid(
                        $columnNames['team_foreign_key']
                    );

                    $table->index(
                        $columnNames['team_foreign_key'],
                        'model_has_permissions_team_foreign_key_index'
                    );

                    if (DB::getDriverName() !== 'sqlite') {
                        $table->dropForeign([$pivotPermission]);
                    }

                    $table->dropPrimary();

                    $table->primary(
                        [
                            $columnNames['team_foreign_key'],
                            $pivotPermission,
                            $columnNames['model_morph_key'],
                            'model_type',
                        ],
                        'model_has_permissions_permission_model_type_primary'
                    );

                    if (DB::getDriverName() !== 'sqlite') {
                        $table->foreign($pivotPermission)
                            ->references('id')
                            ->on($tableNames['permissions'])
                            ->cascadeOnDelete();
                    }
                }
            );

            Schema::table(
                $tableNames['model_has_permissions'],
                function (Blueprint $table) use ($columnNames) {

                    $table->foreign(
                        $columnNames['team_foreign_key']
                    )
                        ->references('id')
                        ->on('businesses')
                        ->cascadeOnDelete();
                }
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Model Has Roles
        |--------------------------------------------------------------------------
        */

        if (! Schema::hasColumn(
            $tableNames['model_has_roles'],
            $columnNames['team_foreign_key']
        )) {
            Schema::table(
                $tableNames['model_has_roles'],
                function (Blueprint $table) use (
                    $tableNames,
                    $columnNames,
                    $pivotRole
                ) {

                    $table->uuid(
                        $columnNames['team_foreign_key']
                    );

                    $table->index(
                        $columnNames['team_foreign_key'],
                        'model_has_roles_team_foreign_key_index'
                    );

                    if (DB::getDriverName() !== 'sqlite') {
                        $table->dropForeign([$pivotRole]);
                    }

                    $table->dropPrimary();

                    $table->primary(
                        [
                            $columnNames['team_foreign_key'],
                            $pivotRole,
                            $columnNames['model_morph_key'],
                            'model_type',
                        ],
                        'model_has_roles_role_model_type_primary'
                    );

                    if (DB::getDriverName() !== 'sqlite') {
                        $table->foreign($pivotRole)
                            ->references('id')
                            ->on($tableNames['roles'])
                            ->cascadeOnDelete();
                    }
                }
            );

            Schema::table(
                $tableNames['model_has_roles'],
                function (Blueprint $table) use ($columnNames) {

                    $table->foreign(
                        $columnNames['team_foreign_key']
                    )
                        ->references('id')
                        ->on('businesses')
                        ->cascadeOnDelete();
                }
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Clear Permission Cache
        |--------------------------------------------------------------------------
        */

        app('cache')
            ->store(
                config('permission.cache.store') !== 'default'
                    ? config('permission.cache.store')
                    : null
            )
            ->forget(
                config('permission.cache.key')
            );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // We intentionally leave this empty for now.
        //
        // This migration modifies package-owned tables.
        // We will handle rollback carefully if we ever need it.
    }
};